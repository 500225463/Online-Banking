SELECT
    c.last_name,
    c.first_name,
    o.order_date,
    p.product_name,
    oi.item_price,
    oi.discount_amount,
    oi.quantity
FROM
    Customers c
JOIN
    Orders o ON c.customer_id = o.customer_id
JOIN
    Order_Items oi ON o.order_id = oi.order_id
JOIN
    Products p ON oi.product_id = p.product_id
ORDER BY
    c.last_name, o.order_date, p.product_name;

SELECT
    c.email_address,
    COUNT(o.order_id) AS order_count,
    SUM((oi.item_price - oi.discount_amount) * oi.quantity) AS total_amount
FROM
    Customers c
JOIN
    Orders o ON c.customer_id = o.customer_id
JOIN
    Order_Items oi ON o.order_id = oi.order_id
GROUP BY
    c.email_address
HAVING
    COUNT(o.order_id) > 1
ORDER BY
    SUM((oi.item_price - oi.discount_amount) * oi.quantity) DESC;

SELECT product_name FROM products;
SELECT COUNT(*) AS number_of_products
FROM products;



